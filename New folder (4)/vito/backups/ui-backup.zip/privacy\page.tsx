'use client';

import { Header, Footer } from '@/components/marketing';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-slate-900 mb-8">Privacy Policy</h1>
          <div className="prose prose-lg prose-slate max-w-none bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-lg">
            <p className="text-slate-500 mb-8">Last updated: January 20, 2026</p>
            <h2>1. Information We Collect</h2>
            <p>We collect information you provide directly, such as account details, project data, and communications with us.</p>

            <h2>2. How We Use Your Information</h2>
            <p>We use your information to provide and improve our services, communicate with you, and ensure security.</p>

            <h2>3. Information Sharing</h2>
            <p>We do not sell your personal information. We may share data with service providers who assist in our operations.</p>

            <h2>4. Data Security</h2>
            <p>We implement industry-standard security measures to protect your data.</p>

            <h2>5. Your Rights</h2>
            <p>You have the right to access, correct, or delete your personal information at any time.</p>

            <h2>6. Contact Us</h2>
            <p>For privacy-related questions, contact us at privacy@olympus.dev</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
