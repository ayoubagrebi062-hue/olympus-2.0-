'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const navItems = [
    { name: 'Features', href: '/features' },
    { name: 'Pricing', href: '/pricing' },
    { name: 'Docs', href: '/docs' },
    { name: 'Blog', href: '/blog' },
  ];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
      scrolled ? 'py-2' : 'py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className={`relative flex items-center justify-between px-6 py-3 rounded-2xl transition-all duration-700 ${
          scrolled
            ? 'bg-white/80 backdrop-blur-2xl shadow-[0_8px_32px_rgba(99,102,241,0.1)] border border-white/50'
            : 'bg-transparent'
        }`}>
          {/* Gradient border on scroll */}
          {scrolled && (
            <div className="absolute inset-0 rounded-2xl p-[1px] bg-gradient-to-r from-indigo-500/20 via-purple-500/20 to-pink-500/20 -z-10">
              <div className="w-full h-full rounded-2xl bg-white/90 backdrop-blur-2xl" />
            </div>
          )}

          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg group-hover:shadow-indigo-500/40 transition-all duration-500 group-hover:scale-110">
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 blur-xl opacity-40 group-hover:opacity-60 transition-opacity" />
            </div>
            <span className="text-2xl font-black tracking-tight">
              <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent">
                OLYMPUS
              </span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="relative px-4 py-2 text-slate-600 hover:text-indigo-600 font-medium transition-all duration-300 rounded-xl group"
              >
                <span className="relative z-10">{item.name}</span>
                <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-indigo-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-indigo-500/10 group-hover:via-purple-500/10 group-hover:to-pink-500/10 transition-all duration-300" />
              </Link>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <Link
              href="/login"
              className="px-5 py-2.5 text-slate-600 hover:text-indigo-600 font-semibold transition-colors"
            >
              Log in
            </Link>
            <Link
              href="/signup"
              className="relative px-6 py-2.5 font-semibold text-white rounded-xl overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 transition-all duration-500 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 blur-xl opacity-50 group-hover:opacity-80 transition-opacity" />
              <span className="relative">Get Started</span>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden relative w-10 h-10 flex items-center justify-center rounded-xl bg-white/50 backdrop-blur-xl border border-white/20"
          >
            <div className={`w-5 flex flex-col gap-1.5 transition-all duration-300 ${menuOpen ? 'rotate-45' : ''}`}>
              <span className={`h-0.5 bg-slate-600 rounded-full transition-all duration-300 ${menuOpen ? 'rotate-90 translate-y-2' : ''}`} />
              <span className={`h-0.5 bg-slate-600 rounded-full transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`} />
              <span className={`h-0.5 bg-slate-600 rounded-full transition-all duration-300 ${menuOpen ? '-rotate-90 -translate-y-2' : ''}`} />
            </div>
          </button>
        </nav>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden absolute top-full left-4 right-4 mt-2 transition-all duration-500 ${
        menuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4 pointer-events-none'
      }`}>
        <div className="p-6 rounded-2xl bg-white/90 backdrop-blur-2xl border border-white/50 shadow-[0_8px_32px_rgba(99,102,241,0.15)]">
          <div className="space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setMenuOpen(false)}
                className="block px-4 py-3 text-slate-600 hover:text-indigo-600 font-medium rounded-xl hover:bg-gradient-to-r hover:from-indigo-500/10 hover:to-purple-500/10 transition-all"
              >
                {item.name}
              </Link>
            ))}
          </div>
          <div className="mt-6 pt-6 border-t border-slate-200/50 space-y-3">
            <Link href="/login" className="block px-4 py-3 text-center text-slate-600 font-semibold rounded-xl hover:bg-slate-100 transition-colors">
              Log in
            </Link>
            <Link href="/signup" className="block px-4 py-3 text-center bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 text-white font-semibold rounded-xl shadow-lg shadow-indigo-500/30">
              Get Started
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
