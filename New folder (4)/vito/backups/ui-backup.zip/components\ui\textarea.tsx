'use client';

import { forwardRef, TextareaHTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Textarea Component
 *
 * Variants: default, ghost, filled
 * States: error, disabled
 */

const textareaVariants = cva(
  // Base styles
  'w-full rounded-lg text-white transition-all duration-200 focus:outline-none placeholder:text-zinc-500 disabled:opacity-50 disabled:cursor-not-allowed resize-none',
  {
    variants: {
      variant: {
        // Default - Standard textarea
        default:
          'bg-zinc-900 border border-zinc-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent',

        // Ghost - Minimal border
        ghost:
          'bg-transparent border border-zinc-800 focus:border-zinc-600 focus:ring-1 focus:ring-zinc-600',

        // Filled - Solid background
        filled:
          'bg-zinc-800 border border-transparent focus:ring-2 focus:ring-blue-500',
      },
      error: {
        true: 'border-red-500 focus:ring-red-500 focus:border-red-500',
        false: '',
      },
    },
    defaultVariants: {
      variant: 'default',
      error: false,
    },
  }
);

export interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement>,
    VariantProps<typeof textareaVariants> {
  label?: string;
  helperText?: string;
  errorMessage?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      variant,
      error,
      label,
      helperText,
      errorMessage,
      className,
      id,
      rows = 4,
      ...props
    },
    ref
  ) => {
    const textareaId =
      id || `textarea-${Math.random().toString(36).slice(2, 9)}`;
    const hasError = error || !!errorMessage;

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={textareaId}
            className="block text-sm font-medium text-zinc-300 mb-2"
          >
            {label}
          </label>
        )}

        <textarea
          ref={ref}
          id={textareaId}
          rows={rows}
          className={cn(
            textareaVariants({ variant, error: hasError }),
            'p-4',
            className
          )}
          {...props}
        />

        {(helperText || errorMessage) && (
          <p
            className={cn(
              'mt-2 text-sm',
              hasError ? 'text-red-400' : 'text-zinc-500'
            )}
          >
            {errorMessage || helperText}
          </p>
        )}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';

export { textareaVariants };
