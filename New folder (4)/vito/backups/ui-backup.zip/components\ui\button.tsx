'use client';

import Link from 'next/link';
import { forwardRef, ButtonHTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Button Component - 50X LIGHT THEME
 *
 * Premium glassmorphism design with LIGHT THEME.
 * Based on Section 10 UI Component System & OLYMPUS_PROTOCOL.
 *
 * Variants: primary, secondary, ghost, outline, gradient, premium, glass, destructive
 * Sizes: xs, sm, md, lg, xl, 2xl, icon, icon-sm, icon-lg
 */

const buttonVariants = cva(
  // Base styles - LIGHT THEME
  'inline-flex items-center justify-center font-medium transition-all duration-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]',
  {
    variants: {
      variant: {
        // Primary - Brand Blue (LIGHT THEME)
        primary:
          'bg-blue-500 text-white hover:bg-blue-600 active:bg-blue-700 focus:ring-blue-500 shadow-md hover:shadow-lg hover:shadow-blue-500/25',

        // Secondary - Slate background (LIGHT THEME)
        secondary:
          'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 focus:ring-slate-400',

        // Ghost - Transparent (LIGHT THEME)
        ghost:
          'text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:ring-slate-400',

        // Outline - Border only (LIGHT THEME)
        outline:
          'border-2 border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400 focus:ring-slate-400',

        // Outline Primary - Blue border
        'outline-primary':
          'border-2 border-blue-500 text-blue-600 hover:bg-blue-50 hover:border-blue-600 focus:ring-blue-500',

        // Gradient - Brand gradient
        gradient:
          'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-white shadow-lg hover:shadow-xl hover:shadow-indigo-500/30 bg-[length:200%_auto] hover:bg-[position:right_center] transition-[background-position] duration-500',

        // Premium - 50X Animated gradient with shimmer
        premium:
          'relative bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white shadow-lg hover:shadow-xl hover:shadow-purple-500/40 bg-[length:200%_auto] animate-[gradient-shift_3s_ease_infinite] overflow-hidden before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/30 before:to-transparent before:animate-[shimmer_2s_infinite] before:-translate-x-full',

        // Glass - 50X Premium Glassmorphism (NOT lazy bg-white/60)
        glass:
          'bg-gradient-to-br from-white/90 to-white/60 backdrop-blur-xl backdrop-saturate-[180%] border border-white/50 text-slate-700 shadow-[0_8px_32px_rgba(99,102,241,0.1),inset_0_0_32px_rgba(255,255,255,0.5)] hover:shadow-[0_20px_60px_rgba(99,102,241,0.2),inset_0_0_32px_rgba(255,255,255,0.6)] hover:border-indigo-200/50',

        // Destructive - Error red
        destructive:
          'bg-red-500 text-white hover:bg-red-600 active:bg-red-700 focus:ring-red-500 shadow-md hover:shadow-lg hover:shadow-red-500/25',

        // Success - Green
        success:
          'bg-green-500 text-white hover:bg-green-600 active:bg-green-700 focus:ring-green-500 shadow-md hover:shadow-lg hover:shadow-green-500/25',

        // Link - Looks like a link
        link: 'text-blue-600 hover:text-blue-700 underline-offset-4 hover:underline focus:ring-blue-500',
      },
      size: {
        xs: 'h-7 px-2 text-xs rounded',
        sm: 'h-8 px-3 text-sm gap-1.5 rounded-md',
        md: 'h-9 px-4 text-sm gap-2 rounded-md',
        default: 'h-10 px-4 py-2 gap-2',
        lg: 'h-11 px-6 text-base gap-2 rounded-md',
        xl: 'h-12 px-8 text-lg gap-2.5 rounded-lg',
        '2xl': 'h-14 px-10 text-xl gap-3 rounded-lg',
        icon: 'h-10 w-10',
        'icon-sm': 'h-8 w-8',
        'icon-lg': 'h-12 w-12',
      },
      fullWidth: {
        true: 'w-full',
        false: '',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'default',
      fullWidth: false,
    },
  }
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  href?: string;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant,
      size,
      fullWidth,
      href,
      loading,
      leftIcon,
      rightIcon,
      children,
      className,
      disabled,
      ...props
    },
    ref
  ) => {
    const isDisabled = disabled || loading;
    const styles = cn(buttonVariants({ variant, size, fullWidth }), className);

    const content = (
      <>
        {loading ? (
          <svg
            className="animate-spin h-4 w-4"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
            />
          </svg>
        ) : (
          leftIcon
        )}
        {children}
        {!loading && rightIcon}
      </>
    );

    if (href && !isDisabled) {
      return (
        <Link href={href} className={styles}>
          {content}
        </Link>
      );
    }

    return (
      <button
        ref={ref}
        className={styles}
        disabled={isDisabled}
        {...props}
      >
        {content}
      </button>
    );
  }
);

Button.displayName = 'Button';

export { buttonVariants };
