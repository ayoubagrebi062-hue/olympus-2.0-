'use client';

const orders = [
  { id: '#3210', customer: 'John Doe', product: 'Premium Headphones', amount: '$299.99', status: 'Delivered' },
  { id: '#3209', customer: 'Jane Smith', product: 'Smart Watch Pro', amount: '$449.99', status: 'Shipped' },
  { id: '#3208', customer: 'Bob Wilson', product: 'Wireless Keyboard', amount: '$129.99', status: 'Processing' },
  { id: '#3207', customer: 'Alice Brown', product: 'Designer Backpack', amount: '$189.99', status: 'Delivered' },
  { id: '#3206', customer: 'Charlie Davis', product: 'Running Shoes', amount: '$159.99', status: 'Pending' },
];

const statusColors: Record<string, string> = {
  Delivered: 'bg-green-100 text-green-700',
  Shipped: 'bg-blue-100 text-blue-700',
  Processing: 'bg-amber-100 text-amber-700',
  Pending: 'bg-slate-100 text-slate-700',
};

export function RecentOrders() {
  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-slate-200">
        <h3 className="font-semibold text-slate-900">Recent Orders</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="text-left px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Order</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Customer</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Product</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Amount</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 text-sm font-medium text-indigo-600">{order.id}</td>
                <td className="px-6 py-4 text-sm text-slate-900">{order.customer}</td>
                <td className="px-6 py-4 text-sm text-slate-600">{order.product}</td>
                <td className="px-6 py-4 text-sm font-medium text-slate-900">{order.amount}</td>
                <td className="px-6 py-4">
                  <span className={`inline-flex px-2.5 py-1 text-xs font-medium rounded-full ${statusColors[order.status]}`}>
                    {order.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
