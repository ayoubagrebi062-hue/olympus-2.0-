'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export function HeroSection() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouse = (e: MouseEvent) => {
      setMousePos({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20,
      });
    };
    window.addEventListener('mousemove', handleMouse);
    return () => window.removeEventListener('mousemove', handleMouse);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Mesh Gradient Background */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-100 via-white to-white" />

      {/* Animated Orbs with Depth */}
      <div
        className="absolute top-20 left-[10%] w-[500px] h-[500px] rounded-full opacity-60"
        style={{
          background: 'radial-gradient(circle, rgba(129,140,248,0.4) 0%, rgba(129,140,248,0) 70%)',
          transform: `translate(${mousePos.x * 0.5}px, ${mousePos.y * 0.5}px)`,
          transition: 'transform 0.3s ease-out',
        }}
      />
      <div
        className="absolute bottom-20 right-[10%] w-[600px] h-[600px] rounded-full opacity-50"
        style={{
          background: 'radial-gradient(circle, rgba(192,132,252,0.4) 0%, rgba(192,132,252,0) 70%)',
          transform: `translate(${mousePos.x * -0.3}px, ${mousePos.y * -0.3}px)`,
          transition: 'transform 0.3s ease-out',
        }}
      />
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full opacity-30"
        style={{
          background: 'radial-gradient(circle, rgba(244,114,182,0.3) 0%, rgba(244,114,182,0) 70%)',
          transform: `translate(calc(-50% + ${mousePos.x * 0.2}px), calc(-50% + ${mousePos.y * 0.2}px))`,
          transition: 'transform 0.3s ease-out',
        }}
      />

      {/* Floating 3D Shapes */}
      <div className="absolute top-32 right-[15%] w-20 h-20 opacity-20" style={{ animation: 'float 8s ease-in-out infinite' }}>
        <div className="w-full h-full rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-500 rotate-12" />
      </div>
      <div className="absolute bottom-40 left-[12%] w-16 h-16 opacity-20" style={{ animation: 'float 10s ease-in-out infinite 1s' }}>
        <div className="w-full h-full rounded-full bg-gradient-to-br from-purple-500 to-pink-500" />
      </div>
      <div className="absolute top-1/2 right-[8%] w-12 h-12 opacity-15" style={{ animation: 'float 12s ease-in-out infinite 2s' }}>
        <div className="w-full h-full rotate-45 bg-gradient-to-br from-pink-500 to-orange-400" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-3 px-5 py-2.5 mb-8 rounded-full bg-white/80 backdrop-blur-2xl border border-white/50 shadow-[0_8px_32px_rgba(99,102,241,0.1)]">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
            </span>
            <span className="text-sm font-semibold text-slate-700">Now in Public Beta</span>
            <span className="px-2.5 py-0.5 text-xs font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-full">NEW</span>
          </div>

          {/* Headline */}
          <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight text-slate-900 mb-8">
            Build Anything.
            <br />
            <span className="relative">
              <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent">
                50X Faster.
              </span>
              <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 300 12" fill="none">
                <path d="M2 10C50 4 100 4 150 7C200 10 250 6 298 2" stroke="url(#gradient)" strokeWidth="4" strokeLinecap="round"/>
                <defs>
                  <linearGradient id="gradient" x1="0" y1="0" x2="300" y2="0">
                    <stop stopColor="#6366f1"/>
                    <stop offset="0.5" stopColor="#a855f7"/>
                    <stop offset="1" stopColor="#ec4899"/>
                  </linearGradient>
                </defs>
              </svg>
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto mb-12 leading-relaxed">
            The <span className="font-semibold text-slate-800">ALL-IN-ONE</span> platform for App Builder, E-commerce,
            Websites, and Mobile Apps. <span className="text-indigo-600 font-semibold">Describe it. Watch it build.</span>
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Link
              href="/signup"
              className="group relative px-8 py-4 font-bold text-lg text-white rounded-2xl overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500" />
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 blur-2xl opacity-50 group-hover:opacity-80 transition-opacity" />
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600" />
              </div>
              <span className="relative flex items-center gap-2">
                Start Building Free
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
            </Link>
            <Link
              href="/demo"
              className="group px-8 py-4 font-semibold text-lg text-slate-700 rounded-2xl bg-white/80 backdrop-blur-2xl border border-white/50 shadow-[0_8px_32px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_32px_rgba(99,102,241,0.15)] hover:border-indigo-200 transition-all duration-500 flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500/10 to-purple-500/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <svg className="w-5 h-5 text-indigo-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </div>
              Watch Demo
            </Link>
          </div>

          {/* Preview Card - Premium Glass Effect */}
          <div className="relative max-w-5xl mx-auto">
            {/* Outer Glow */}
            <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500/20 via-purple-500/20 to-pink-500/20 rounded-[2.5rem] blur-2xl" />

            {/* Glass Container */}
            <div className="relative p-3 rounded-[2rem] bg-white/60 backdrop-blur-2xl border border-white/50 shadow-[0_32px_64px_rgba(99,102,241,0.15)]">
              {/* Inner Glow */}
              <div className="absolute inset-0 rounded-[2rem] bg-gradient-to-br from-white/80 via-transparent to-transparent" />

              {/* Gradient Border Effect */}
              <div className="absolute inset-0 rounded-[2rem] p-[1px] bg-gradient-to-br from-indigo-500/30 via-purple-500/30 to-pink-500/30 -z-10" />

              {/* Code Preview */}
              <div className="relative rounded-[1.5rem] bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6 md:p-8 overflow-hidden">
                {/* Noise texture */}
                <div className="absolute inset-0 opacity-[0.03]" style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`
                }} />

                {/* Window Controls */}
                <div className="flex items-center gap-3 mb-6">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500 shadow-lg shadow-red-500/30" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500 shadow-lg shadow-yellow-500/30" />
                    <div className="w-3 h-3 rounded-full bg-green-500 shadow-lg shadow-green-500/30" />
                  </div>
                  <div className="flex-1 flex justify-center">
                    <div className="px-4 py-1.5 rounded-lg bg-slate-700/50 backdrop-blur text-slate-400 text-sm font-mono">
                      olympus-app/src/App.tsx
                    </div>
                  </div>
                </div>

                {/* Code with Syntax Highlighting */}
                <pre className="text-left text-sm md:text-base font-mono overflow-x-auto">
                  <code>
                    <span className="text-slate-500">{"// AI-generated in seconds"}</span>{`
`}<span className="text-purple-400">export default</span> <span className="text-blue-400">function</span> <span className="text-yellow-300">App</span>() {"{"}
  <span className="text-purple-400">return</span> (
    {"<"}<span className="text-green-400">Dashboard</span>{">"}
      {"<"}<span className="text-green-400">Sidebar</span> <span className="text-cyan-300">items</span>={"{"}<span className="text-orange-300">navItems</span>{"}"} {"/>"}
      {"<"}<span className="text-green-400">MainContent</span>{">"}
        {"<"}<span className="text-green-400">Analytics</span> <span className="text-cyan-300">data</span>={"{"}<span className="text-orange-300">metrics</span>{"}"} {"/>"}
        {"<"}<span className="text-green-400">RecentOrders</span> <span className="text-cyan-300">limit</span>={"{"}<span className="text-orange-300">5</span>{"}"} {"/>"}
      {"</"}<span className="text-green-400">MainContent</span>{">"}
    {"</"}<span className="text-green-400">Dashboard</span>{">"}
  );
{"}"}
                  </code>
                </pre>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
