'use client';

import { ProductCard } from './ProductCard';

const SAMPLE_PRODUCTS = [
  { id: '1', name: 'Premium Headphones', price: 299.99, image: '🎧', category: 'Electronics', rating: 4.8 },
  { id: '2', name: 'Smart Watch Pro', price: 449.99, image: '⌚', category: 'Electronics', rating: 4.6 },
  { id: '3', name: 'Wireless Keyboard', price: 129.99, image: '⌨️', category: 'Accessories', rating: 4.4 },
  { id: '4', name: 'Designer Backpack', price: 189.99, image: '🎒', category: 'Fashion', rating: 4.7 },
  { id: '5', name: 'Running Shoes', price: 159.99, image: '👟', category: 'Sports', rating: 4.5 },
  { id: '6', name: 'Portable Speaker', price: 79.99, image: '🔊', category: 'Electronics', rating: 4.3 },
  { id: '7', name: 'Sunglasses', price: 199.99, image: '🕶️', category: 'Fashion', rating: 4.9 },
  { id: '8', name: 'Coffee Maker', price: 249.99, image: '☕', category: 'Home', rating: 4.6 },
];

export function ProductGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {SAMPLE_PRODUCTS.map((product) => (
        <ProductCard key={product.id} {...product} />
      ))}
    </div>
  );
}
