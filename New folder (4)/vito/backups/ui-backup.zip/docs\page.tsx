'use client';

import Link from 'next/link';
import { Header, Footer } from '@/components/marketing';

/**
 * OLYMPUS Docs Page - 50X LIGHT THEME
 *
 * Premium glassmorphism design (NOT lazy bg-white/60).
 * Based on Section 10 UI Component System & OLYMPUS_PROTOCOL.
 */

const sections = [
  { icon: '🚀', title: 'Getting Started', desc: 'Learn the basics of OLYMPUS in 5 minutes.', href: '/docs/getting-started' },
  { icon: '⚡', title: 'AI Generation', desc: 'How to use natural language to build apps.', href: '/docs/ai-generation' },
  { icon: '🎨', title: 'Visual Builder', desc: 'Master the drag-and-drop interface.', href: '/docs/visual-builder' },
  { icon: '📦', title: 'Components', desc: 'Explore our 100+ pre-built components.', href: '/docs/components' },
  { icon: '🗄️', title: 'Database', desc: 'Connect and manage your data.', href: '/docs/database' },
  { icon: '🚢', title: 'Deployment', desc: 'Deploy your app to production.', href: '/docs/deployment' },
];

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/80 relative">
      {/* 50X Mesh Background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(at 40% 20%, rgba(99, 102, 241, 0.08) 0px, transparent 50%),
            radial-gradient(at 80% 0%, rgba(139, 92, 246, 0.08) 0px, transparent 50%),
            radial-gradient(at 0% 50%, rgba(236, 72, 153, 0.04) 0px, transparent 50%),
            radial-gradient(at 80% 50%, rgba(59, 130, 246, 0.06) 0px, transparent 50%),
            radial-gradient(at 0% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%)
          `,
        }}
      />

      <Header />
      <main className="pt-24 pb-16 relative z-10">
        <div className="max-w-4xl mx-auto px-4">
          <section className="py-16 text-center">
            <h1 className="text-5xl font-bold text-slate-900 mb-6">
              <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Documentation
              </span>
            </h1>
            <p className="text-xl text-slate-600">
              Everything you need to build with OLYMPUS.
            </p>
          </section>

          <div className="grid md:grid-cols-2 gap-6">
            {sections.map((s) => (
              <Link key={s.title} href={s.href}>
                {/* 50X Premium Glass Card - NOT lazy bg-white/60 */}
                <div
                  className="
                    p-6 h-full rounded-2xl
                    bg-gradient-to-br from-white/90 to-white/60
                    backdrop-blur-xl backdrop-saturate-[180%]
                    border border-white/50
                    shadow-[0_8px_32px_rgba(99,102,241,0.1),inset_0_0_32px_rgba(255,255,255,0.5),0_0_0_1px_rgba(255,255,255,0.1)]
                    hover:shadow-[0_20px_60px_rgba(99,102,241,0.2),inset_0_0_32px_rgba(255,255,255,0.6),0_0_0_1px_rgba(99,102,241,0.2)]
                    hover:-translate-y-2 hover:scale-[1.02]
                    transition-all duration-300 ease-out
                    cursor-pointer
                  "
                >
                  <div className="text-3xl mb-4">{s.icon}</div>
                  <h2 className="text-lg font-semibold text-slate-900 mb-2">{s.title}</h2>
                  <p className="text-slate-600 text-sm">{s.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
