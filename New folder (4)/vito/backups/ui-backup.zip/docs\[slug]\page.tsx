'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { Header, Footer } from '@/components/marketing';

const docs: Record<string, { title: string; content: string; icon: string }> = {
  'getting-started': {
    title: 'Getting Started',
    icon: '🚀',
    content: `Welcome to OLYMPUS! This guide will help you get up and running in 5 minutes.

## Create Your Account

1. Visit olympus.dev and click "Start Free"
2. Sign up with your email or GitHub account
3. Verify your email address

## Create Your First Project

1. Click "New Project" from your dashboard
2. Choose a template or start from scratch
3. Give your project a name

## Using the AI Builder

1. Open the AI panel (press Cmd+K)
2. Describe what you want to build
3. Watch as OLYMPUS generates your code

## Using the Visual Builder

1. Switch to Visual mode
2. Drag components from the sidebar
3. Click to select and edit properties

## Deploy Your App

1. Click the "Deploy" button
2. Choose your deployment settings
3. Your app is now live!

That is it! You have created and deployed your first OLYMPUS app.`,
  },
  'ai-generation': {
    title: 'AI Generation',
    icon: '⚡',
    content: `Learn how to use OLYMPUS AI to generate code from natural language.

## Basic Usage

Press Cmd+K (or Ctrl+K on Windows) to open the AI panel. Type what you want to build in plain English.

### Examples

- "Create a contact form with name, email, and message fields"
- "Add a navigation bar with logo and links"
- "Build a pricing table with 3 tiers"

## Tips for Better Results

### Be Specific
Instead of "make a form", say "create a contact form with validation that sends to my email".

### Provide Context
Tell the AI about your app: "This is a SaaS dashboard, add a sidebar with user profile".

### Iterate
Start simple, then ask for refinements: "Make the button blue" or "Add hover effects".

## Advanced Features

### Multi-step Generation
Break complex features into steps for better results.

### Code Review
Ask the AI to review and improve existing code.

### Documentation
Generate comments and documentation automatically.`,
  },
  'visual-builder': {
    title: 'Visual Builder',
    icon: '🎨',
    content: `Master the drag-and-drop visual builder.

## Interface Overview

- **Left Sidebar**: Component library
- **Center Canvas**: Your page preview
- **Right Panel**: Properties and styles

## Adding Components

1. Browse the component library
2. Drag a component onto the canvas
3. Drop it where you want it

## Editing Components

1. Click to select a component
2. Edit properties in the right panel
3. Changes appear in real-time

## Layout Tools

### Containers
Use Flex and Grid containers for layouts.

### Spacing
Adjust padding and margin with visual controls.

### Responsive
Toggle device views to design for all screens.

## Keyboard Shortcuts

- **Cmd+C**: Copy selected
- **Cmd+V**: Paste
- **Cmd+Z**: Undo
- **Cmd+Shift+Z**: Redo
- **Delete**: Remove selected`,
  },
  'components': {
    title: 'Components',
    icon: '📦',
    content: `Explore our library of 100+ pre-built components.

## Categories

### Layout
- Container, Grid, Flex, Stack, Divider

### Navigation
- Navbar, Sidebar, Tabs, Breadcrumb, Pagination

### Forms
- Input, Textarea, Select, Checkbox, Radio, Switch

### Data Display
- Table, Card, List, Badge, Avatar, Tooltip

### Feedback
- Alert, Toast, Modal, Drawer, Progress

### E-commerce
- ProductCard, Cart, Checkout, PriceTag

## Using Components

### From Visual Builder
Drag and drop from the sidebar.

### From AI
Ask the AI to add specific components.

### From Code
Import from @/components library.

## Customizing Components

All components accept props for customization:
- Colors and themes
- Sizes and spacing
- Variants and states`,
  },
  'database': {
    title: 'Database',
    icon: '🗄️',
    content: `Connect and manage your data with OLYMPUS.

## Supported Databases

- **PostgreSQL**: Full support
- **MySQL**: Full support
- **MongoDB**: Full support
- **Supabase**: Native integration
- **Firebase**: Native integration

## Connecting Your Database

1. Go to Project Settings > Database
2. Enter your connection string
3. Click "Test Connection"
4. Save your settings

## Working with Data

### Models
Define your data models in the Models tab.

### Queries
Use the Query Builder or write raw SQL.

### Migrations
OLYMPUS handles migrations automatically.

## Best Practices

- Use environment variables for credentials
- Set up proper indexes
- Enable connection pooling
- Regular backups`,
  },
  'deployment': {
    title: 'Deployment',
    icon: '🚢',
    content: `Deploy your OLYMPUS app to production.

## One-Click Deploy

1. Click "Deploy" in the top bar
2. Choose your settings
3. Done! Your app is live

## Deployment Options

### OLYMPUS Cloud (Recommended)
- Zero configuration
- Global CDN
- Automatic SSL
- DDoS protection

### Vercel
- Native integration
- Preview deployments
- Edge functions

### Custom
- Export your code
- Deploy anywhere

## Environment Variables

1. Go to Settings > Environment
2. Add your variables
3. Redeploy to apply

## Custom Domains

1. Go to Settings > Domains
2. Add your domain
3. Update DNS records
4. SSL is automatic

## Monitoring

- View deployment logs
- Monitor performance
- Set up alerts`,
  },
};

export default function DocsPage() {
  const params = useParams();
  const slug = params?.slug as string;
  const doc = docs[slug];

  if (!doc) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
        <Header />
        <main className="pt-24 pb-16">
          <div className="max-w-4xl mx-auto px-4 text-center py-24">
            <h1 className="text-4xl font-bold text-slate-900 mb-4">Page Not Found</h1>
            <p className="text-slate-600 mb-8">The documentation page you are looking for does not exist.</p>
            <Link href="/docs" className="text-indigo-600 hover:text-indigo-700 font-medium">
              Back to Documentation
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const docKeys = Object.keys(docs);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-8">
            {/* Sidebar */}
            <aside className="hidden lg:block w-64 shrink-0">
              <nav className="sticky top-24 space-y-1">
                {docKeys.map((key) => (
                  <Link
                    key={key}
                    href={`/docs/${key}`}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      key === slug
                        ? 'bg-gradient-to-r from-indigo-500/10 to-purple-500/10 text-indigo-600 font-medium'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span>{docs[key].icon}</span>
                    <span>{docs[key].title}</span>
                  </Link>
                ))}
              </nav>
            </aside>

            {/* Content */}
            <article className="flex-1 max-w-3xl">
              {/* Breadcrumb */}
              <div className="flex items-center gap-2 text-sm text-slate-500 mb-8">
                <Link href="/docs" className="hover:text-indigo-600">Docs</Link>
                <span>/</span>
                <span className="text-slate-900">{doc.title}</span>
              </div>

              {/* Header */}
              <header className="mb-8">
                <div className="text-4xl mb-4">{doc.icon}</div>
                <h1 className="text-4xl font-bold text-slate-900">{doc.title}</h1>
              </header>

              {/* Content */}
              <div className="prose prose-lg prose-slate max-w-none">
                {doc.content.split('\n\n').map((paragraph, i) => {
                  if (paragraph.startsWith('## ')) {
                    return <h2 key={i} className="text-2xl font-bold text-slate-900 mt-8 mb-4">{paragraph.replace('## ', '')}</h2>;
                  }
                  if (paragraph.startsWith('### ')) {
                    return <h3 key={i} className="text-xl font-semibold text-slate-900 mt-6 mb-3">{paragraph.replace('### ', '')}</h3>;
                  }
                  if (paragraph.startsWith('- ')) {
                    return (
                      <ul key={i} className="list-disc list-inside space-y-2 my-4">
                        {paragraph.split('\n').map((item, j) => (
                          <li key={j} className="text-slate-600">{item.replace('- ', '')}</li>
                        ))}
                      </ul>
                    );
                  }
                  if (paragraph.match(/^\d+\./)) {
                    return (
                      <ol key={i} className="list-decimal list-inside space-y-2 my-4">
                        {paragraph.split('\n').map((item, j) => (
                          <li key={j} className="text-slate-600">{item.replace(/^\d+\.\s*/, '')}</li>
                        ))}
                      </ol>
                    );
                  }
                  return <p key={i} className="text-slate-600 mb-4">{paragraph}</p>;
                })}
              </div>
            </article>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
