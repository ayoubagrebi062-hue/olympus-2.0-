'use client';

import { forwardRef, HTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Card Component - 50X LIGHT THEME
 *
 * Premium glassmorphism design with LIGHT THEME.
 * Based on Section 10 UI Component System & OLYMPUS_PROTOCOL.
 *
 * Variants: default, elevated, glass, glass-premium, gradient-border, interactive
 * NOT lazy bg-white/60 - uses multi-layer shadows and gradient borders
 */

const cardVariants = cva(
  // Base styles - LIGHT THEME
  'rounded-xl transition-all duration-300',
  {
    variants: {
      variant: {
        // Default - Clean white (LIGHT THEME)
        default: 'bg-white border border-slate-200 shadow-sm',

        // Elevated - With shadow
        elevated: 'bg-white border-transparent shadow-lg',

        // Outline - Border only
        outline: 'bg-transparent border border-slate-200 shadow-none',

        // Filled - Subtle background
        filled: 'bg-slate-50 border-transparent shadow-none',

        // Ghost - Transparent
        ghost: 'bg-transparent border-transparent shadow-none',

        // Glass - 50X Premium Glassmorphism (NOT lazy bg-white/60)
        glass: `
          bg-gradient-to-br from-white/90 to-white/60
          backdrop-blur-xl backdrop-saturate-[180%]
          border border-white/50
          shadow-[0_8px_32px_rgba(99,102,241,0.1),inset_0_0_32px_rgba(255,255,255,0.5),0_0_0_1px_rgba(255,255,255,0.1)]
        `,

        // Glass Premium - 50X with hover animation
        'glass-premium': `
          bg-gradient-to-br from-white/90 to-white/60
          backdrop-blur-xl backdrop-saturate-[180%]
          border border-white/50
          shadow-[0_8px_32px_rgba(99,102,241,0.1),inset_0_0_32px_rgba(255,255,255,0.5),0_0_0_1px_rgba(255,255,255,0.1)]
          hover:shadow-[0_20px_60px_rgba(99,102,241,0.2),inset_0_0_32px_rgba(255,255,255,0.6),0_0_0_1px_rgba(99,102,241,0.2)]
          hover:-translate-y-2 hover:scale-[1.02]
        `,

        // Gradient Border - 50X Animated gradient border
        'gradient-border': `
          bg-gradient-to-br from-white/80 to-white/40
          backdrop-blur-xl
          relative
          before:content-[''] before:absolute before:inset-0 before:p-[2px] before:rounded-xl
          before:bg-gradient-to-br before:from-indigo-400 before:via-purple-400 before:to-pink-400
          before:-z-10 before:animate-[border-dance_4s_ease-in-out_infinite] before:bg-[length:200%_200%]
          before:[mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)]
          before:[mask-composite:exclude]
        `,

        // Interactive - Has hover states
        interactive: `
          bg-white border border-slate-200 shadow-sm
          hover:shadow-md hover:border-blue-200/50 hover:-translate-y-1
          cursor-pointer
        `,
      },
      padding: {
        none: 'p-0',
        sm: 'p-3',
        md: 'p-4',
        lg: 'p-6',
        xl: 'p-8',
      },
      glow: {
        brand: 'shadow-[0_0_40px_rgba(59,130,246,0.25)]',
        indigo: 'shadow-[0_0_60px_rgba(99,102,241,0.4)]',
        purple: 'shadow-[0_0_60px_rgba(139,92,246,0.4)]',
        pink: 'shadow-[0_0_60px_rgba(236,72,153,0.4)]',
        none: '',
      },
    },
    defaultVariants: {
      variant: 'default',
      padding: 'none',
      glow: 'none',
    },
  }
);

export interface CardProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof cardVariants> {}

const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ variant, padding, glow, className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn(cardVariants({ variant, padding, glow }), className)}
      {...props}
    />
  )
);
Card.displayName = 'Card';

// Card Header
const CardHeader = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn('flex flex-col space-y-1.5', className)}
      {...props}
    />
  )
);
CardHeader.displayName = 'CardHeader';

// Card Title - LIGHT THEME
const CardTitle = forwardRef<
  HTMLParagraphElement,
  HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h3
    ref={ref}
    className={cn(
      'text-xl font-semibold leading-none tracking-tight text-slate-900',
      className
    )}
    {...props}
  />
));
CardTitle.displayName = 'CardTitle';

// Card Description - LIGHT THEME
const CardDescription = forwardRef<
  HTMLParagraphElement,
  HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    className={cn('text-sm text-slate-500', className)}
    {...props}
  />
));
CardDescription.displayName = 'CardDescription';

// Card Content
const CardContent = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn('', className)} {...props} />
  )
);
CardContent.displayName = 'CardContent';

// Card Footer
const CardFooter = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn('flex items-center pt-4', className)}
      {...props}
    />
  )
);
CardFooter.displayName = 'CardFooter';

export {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  cardVariants,
};
