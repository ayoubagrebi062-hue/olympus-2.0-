'use client';

import Link from 'next/link';
import { Header, Footer } from '@/components/marketing';

export default function PlaceholderPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4 text-center py-24">
          <div className="w-20 h-20 mx-auto mb-8 rounded-2xl bg-gradient-to-br from-indigo-500/10 to-purple-500/10 flex items-center justify-center">
            <span className="text-4xl">🚧</span>
          </div>
          <h1 className="text-4xl font-bold text-slate-900 mb-4">Coming Soon</h1>
          <p className="text-xl text-slate-600 mb-8">
            This page is under construction. Check back soon!
          </p>
          <Link
            href="/"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all"
          >
            Back to Home
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
