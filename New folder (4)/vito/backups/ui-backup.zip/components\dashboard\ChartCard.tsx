'use client';

interface ChartCardProps {
  title: string;
  subtitle?: string;
}

export function ChartCard({ title, subtitle }: ChartCardProps) {
  // Simple bar chart visualization
  const data = [40, 65, 45, 80, 55, 70, 90];
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const maxValue = Math.max(...data);

  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-6 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold text-slate-900">{title}</h3>
          {subtitle && <p className="text-sm text-slate-500">{subtitle}</p>}
        </div>
        <select className="px-3 py-1.5 text-sm bg-slate-100 border-0 rounded-lg focus:ring-2 focus:ring-indigo-500">
          <option>This Week</option>
          <option>This Month</option>
          <option>This Year</option>
        </select>
      </div>

      {/* Chart */}
      <div className="flex items-end justify-between gap-2 h-48">
        {data.map((value, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-2">
            <div
              className="w-full bg-gradient-to-t from-indigo-600 to-purple-600 rounded-t-lg transition-all hover:opacity-80"
              style={{ height: `${(value / maxValue) * 100}%` }}
            />
            <span className="text-xs text-slate-500">{days[i]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
