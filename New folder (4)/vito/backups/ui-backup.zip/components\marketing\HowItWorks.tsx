'use client';

const steps = [
  {
    number: '01',
    title: 'Describe Your Vision',
    description: 'Tell OLYMPUS what you want to build in plain English. Our AI understands context, intent, and best practices.',
    icon: '💬',
    gradient: 'from-indigo-500 to-purple-500',
  },
  {
    number: '02',
    title: 'Watch It Build',
    description: 'See your app come to life in real-time. Every component, every line of code, generated before your eyes.',
    icon: '⚡',
    gradient: 'from-purple-500 to-pink-500',
  },
  {
    number: '03',
    title: 'Customize & Refine',
    description: 'Use our visual editor to tweak layouts, colors, and content. Or dive into the code for full control.',
    icon: '🎨',
    gradient: 'from-pink-500 to-rose-500',
  },
  {
    number: '04',
    title: 'Deploy Instantly',
    description: 'One click to go live. Your app is deployed globally with SSL, CDN, and automatic scaling.',
    icon: '🚀',
    gradient: 'from-amber-500 to-orange-500',
  },
];

export function HowItWorks() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-white via-purple-50/20 to-white" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 backdrop-blur-xl border border-white/50 shadow-lg mb-6">
            <span className="text-sm font-semibold text-indigo-600">How It Works</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6">
            From idea to production in{' '}
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent">
              4 simple steps
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            No coding bootcamp required. If you can describe it, you can build it.
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, i) => (
            <div key={i} className="relative">
              {/* Connector Line */}
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-full w-full h-[2px] -translate-x-1/2 z-0">
                  <div className="w-full h-full bg-gradient-to-r from-indigo-200 via-purple-200 to-pink-200" />
                </div>
              )}

              <div className="group relative p-8 rounded-2xl bg-white/80 backdrop-blur-2xl border border-white/50 shadow-[0_8px_32px_rgba(0,0,0,0.04)] hover:shadow-[0_16px_48px_rgba(99,102,241,0.15)] transition-all duration-500 hover:-translate-y-2">
                {/* Number Badge */}
                <div className={`absolute -top-4 -left-4 w-10 h-10 rounded-xl bg-gradient-to-br ${step.gradient} flex items-center justify-center text-white font-black text-sm shadow-lg`}>
                  {step.number}
                </div>

                {/* Icon */}
                <div className="text-4xl mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                  {step.icon}
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-slate-900 mb-3">{step.title}</h3>
                <p className="text-slate-600 leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
