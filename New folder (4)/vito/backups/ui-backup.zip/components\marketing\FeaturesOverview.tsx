'use client';

const features = [
  {
    icon: '⚡',
    title: 'AI-Powered Generation',
    description: 'Describe what you want in plain English. Our AI understands context and builds production-ready code.',
    gradient: 'from-amber-500 to-orange-500',
  },
  {
    icon: '🎨',
    title: 'Visual Builder',
    description: 'Drag and drop components. See changes instantly. Switch to code view anytime for full control.',
    gradient: 'from-purple-500 to-pink-500',
  },
  {
    icon: '🚀',
    title: 'One-Click Deploy',
    description: 'Deploy to production with one click. Global CDN, automatic SSL, instant scaling included.',
    gradient: 'from-cyan-500 to-blue-500',
  },
  {
    icon: '🛒',
    title: 'E-commerce Ready',
    description: 'Stripe integration, inventory management, order tracking. Launch your store in minutes.',
    gradient: 'from-green-500 to-emerald-500',
  },
  {
    icon: '📱',
    title: 'Mobile First',
    description: 'Every app is responsive by default. Export to iOS and Android with a single codebase.',
    gradient: 'from-indigo-500 to-violet-500',
  },
  {
    icon: '🔒',
    title: 'Enterprise Security',
    description: 'SOC 2 compliant. SSO/SAML support. Audit logs. Your data is encrypted at rest and in transit.',
    gradient: 'from-rose-500 to-red-500',
  },
];

export function FeaturesOverview() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-white via-purple-50/20 to-white" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 backdrop-blur-xl border border-white/50 shadow-lg mb-6">
            <span className="text-sm font-semibold text-indigo-600">Features</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6">
            Everything you need to{' '}
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent">
              build & ship
            </span>
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            One platform replaces your entire tech stack. From idea to production in minutes.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={feature.title}
              className="group relative p-8 rounded-2xl bg-white/80 backdrop-blur-2xl border border-white/50 shadow-[0_8px_32px_rgba(0,0,0,0.04)] hover:shadow-[0_16px_48px_rgba(99,102,241,0.15)] transition-all duration-500 hover:-translate-y-2"
            >
              {/* Gradient Glow on Hover */}
              <div className={`absolute -inset-px rounded-2xl bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500 blur-xl`} />

              {/* Icon */}
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center text-2xl mb-6 shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-500`}>
                {feature.icon}
              </div>

              {/* Content */}
              <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-indigo-600 transition-colors">
                {feature.title}
              </h3>
              <p className="text-slate-600 leading-relaxed">
                {feature.description}
              </p>

              {/* Arrow */}
              <div className="mt-6 flex items-center gap-2 text-indigo-600 font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span>Learn more</span>
                <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
