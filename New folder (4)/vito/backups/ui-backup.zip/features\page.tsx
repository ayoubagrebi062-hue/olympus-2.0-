'use client';

import { Header, Footer } from '@/components/marketing';

const features = [
  {
    category: 'AI-Powered Generation',
    icon: '⚡',
    gradient: 'from-indigo-500 to-purple-500',
    items: [
      { title: 'Natural Language Input', desc: 'Describe your app in plain English. Our AI understands context and intent.' },
      { title: 'Real-Time Code Generation', desc: 'Watch as your app is built line by line with full transparency.' },
      { title: 'Smart Suggestions', desc: 'AI suggests improvements and catches potential issues automatically.' },
      { title: 'Context-Aware Editing', desc: 'Make changes by describing what you want. AI understands your codebase.' },
    ],
  },
  {
    category: 'Visual Builder',
    icon: '🎨',
    gradient: 'from-purple-500 to-pink-500',
    items: [
      { title: 'Drag & Drop Interface', desc: 'Build layouts visually by dragging components. No coding required.' },
      { title: 'Real-Time Preview', desc: 'See changes instantly. Desktop, tablet, and mobile views.' },
      { title: 'Component Library', desc: '100+ pre-built components. Buttons, forms, cards, charts.' },
      { title: 'Full Code Access', desc: 'Switch to code view anytime. Clean, readable code.' },
    ],
  },
  {
    category: 'One-Click Deploy',
    icon: '🚀',
    gradient: 'from-cyan-500 to-blue-500',
    items: [
      { title: 'Vercel Integration', desc: 'Deploy with one click. Automatic builds and previews.' },
      { title: 'Custom Domains', desc: 'Connect your own domain. SSL configured automatically.' },
      { title: 'Global CDN', desc: 'Your app served from 100+ edge locations worldwide.' },
      { title: 'Environment Variables', desc: 'Manage secrets securely. Different values per environment.' },
    ],
  },
  {
    category: 'E-commerce Ready',
    icon: '🛒',
    gradient: 'from-orange-500 to-amber-500',
    items: [
      { title: 'Stripe Integration', desc: 'Accept payments in minutes. Cards, wallets, local methods.' },
      { title: 'Product Management', desc: 'Inventory, variants, pricing. Everything organized.' },
      { title: 'Order Fulfillment', desc: 'Track orders, manage shipping, handle returns.' },
      { title: 'Analytics Dashboard', desc: 'Sales, conversion rates, customer insights.' },
    ],
  },
];

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        {/* Hero */}
        <section className="py-16 text-center">
          <div className="max-w-4xl mx-auto px-4">
            <h1 className="text-5xl font-bold text-slate-900 mb-6">
              Everything You Need to{' '}
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Build & Ship
              </span>
            </h1>
            <p className="text-xl text-slate-600">
              One platform replaces your entire tech stack. From idea to production in minutes.
            </p>
          </div>
        </section>

        {/* Features */}
        {features.map((section, i) => (
          <section key={i} className={`py-16 ${i % 2 === 1 ? 'bg-white/50' : ''}`}>
            <div className="max-w-7xl mx-auto px-4">
              <div className="flex items-center gap-4 mb-8">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${section.gradient} flex items-center justify-center text-2xl shadow-lg`}>
                  {section.icon}
                </div>
                <h2 className="text-3xl font-bold text-slate-900">{section.category}</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                {section.items.map((item, j) => (
                  <div key={j} className="p-6 bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl shadow-lg hover:shadow-xl transition-all">
                    <h3 className="font-semibold text-slate-900 mb-2">{item.title}</h3>
                    <p className="text-slate-600">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        ))}
      </main>
      <Footer />
    </div>
  );
}
