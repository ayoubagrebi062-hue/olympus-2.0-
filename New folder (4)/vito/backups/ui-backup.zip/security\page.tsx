'use client';

import { Header, Footer } from '@/components/marketing';

export default function SecurityPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-slate-900 mb-8">Security</h1>
          <div className="prose prose-lg prose-slate max-w-none bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-lg">
            <p className="text-slate-500 mb-8">Last updated: January 20, 2026</p>
            <h2>Our Security Commitment</h2>
            <p>Security is fundamental to OLYMPUS. We implement comprehensive measures to protect your data.</p>

            <h2>Infrastructure Security</h2>
            <p>All data is encrypted in transit (TLS 1.3) and at rest (AES-256). Our infrastructure runs on SOC 2 compliant providers.</p>

            <h2>Application Security</h2>
            <p>Regular security audits, penetration testing, and vulnerability scanning. Bug bounty program for responsible disclosure.</p>

            <h2>Access Controls</h2>
            <p>Role-based access control, multi-factor authentication, and single sign-on (SSO) for enterprise plans.</p>

            <h2>Data Protection</h2>
            <p>Automated backups, disaster recovery procedures, and data retention policies aligned with industry standards.</p>

            <h2>Report a Vulnerability</h2>
            <p>Found a security issue? Email security@olympus.dev. We appreciate responsible disclosure.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
