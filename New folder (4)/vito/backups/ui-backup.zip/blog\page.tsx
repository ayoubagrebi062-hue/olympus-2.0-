'use client';

import Link from 'next/link';
import { Header, Footer } from '@/components/marketing';

/**
 * OLYMPUS Blog Page - 50X LIGHT THEME
 *
 * Premium glassmorphism design (NOT lazy bg-white/60).
 * Based on Section 10 UI Component System & OLYMPUS_PROTOCOL.
 */

const posts = [
  { slug: '1', title: 'Introducing OLYMPUS 2.0', desc: 'The biggest update yet with AI-powered code generation.', date: 'Jan 20, 2026', category: 'Product' },
  { slug: '2', title: 'How to Build an E-commerce Store in 10 Minutes', desc: 'Step-by-step guide to launching your online store.', date: 'Jan 18, 2026', category: 'Tutorial' },
  { slug: '3', title: 'The Future of No-Code Development', desc: 'Why AI is changing everything about how we build software.', date: 'Jan 15, 2026', category: 'Industry' },
  { slug: '4', title: 'Case Study: How Startup X Saved 6 Months', desc: 'Real results from real customers using OLYMPUS.', date: 'Jan 12, 2026', category: 'Case Study' },
];

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50/80 relative">
      {/* 50X Mesh Background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(at 40% 20%, rgba(99, 102, 241, 0.08) 0px, transparent 50%),
            radial-gradient(at 80% 0%, rgba(139, 92, 246, 0.08) 0px, transparent 50%),
            radial-gradient(at 0% 50%, rgba(236, 72, 153, 0.04) 0px, transparent 50%),
            radial-gradient(at 80% 50%, rgba(59, 130, 246, 0.06) 0px, transparent 50%),
            radial-gradient(at 0% 100%, rgba(99, 102, 241, 0.08) 0px, transparent 50%)
          `,
        }}
      />

      <Header />
      <main className="pt-24 pb-16 relative z-10">
        <div className="max-w-4xl mx-auto px-4">
          <section className="py-16 text-center">
            <h1 className="text-5xl font-bold text-slate-900 mb-6">
              <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Blog
              </span>
            </h1>
            <p className="text-xl text-slate-600">
              News, tutorials, and insights from the OLYMPUS team.
            </p>
          </section>

          <div className="space-y-6">
            {posts.map((post) => (
              <Link key={post.slug} href={`/blog/${post.slug}`}>
                {/* 50X Premium Glass Card - NOT lazy bg-white/60 */}
                <article
                  className="
                    p-6 rounded-2xl
                    bg-gradient-to-br from-white/90 to-white/60
                    backdrop-blur-xl backdrop-saturate-[180%]
                    border border-white/50
                    shadow-[0_8px_32px_rgba(99,102,241,0.1),inset_0_0_32px_rgba(255,255,255,0.5),0_0_0_1px_rgba(255,255,255,0.1)]
                    hover:shadow-[0_20px_60px_rgba(99,102,241,0.2),inset_0_0_32px_rgba(255,255,255,0.6),0_0_0_1px_rgba(99,102,241,0.2)]
                    hover:-translate-y-2 hover:scale-[1.01]
                    transition-all duration-300 ease-out
                    cursor-pointer
                  "
                >
                  <div className="flex items-center gap-4 mb-3">
                    <span className="px-3 py-1 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 text-indigo-700 text-xs font-medium rounded-full border border-indigo-200/50">
                      {post.category}
                    </span>
                    <span className="text-slate-500 text-sm">{post.date}</span>
                  </div>
                  <h2 className="text-xl font-semibold text-slate-900 mb-2">{post.title}</h2>
                  <p className="text-slate-600">{post.desc}</p>
                </article>
              </Link>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
