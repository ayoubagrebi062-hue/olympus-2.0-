'use client';

import { Header, Footer } from '@/components/marketing';
import { ProductGrid } from '@/components/ecommerce';

export default function ShopPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Hero */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
              Shop Our{' '}
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Collection
              </span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              Discover premium products curated just for you.
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8 p-4 bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl">
            <div className="flex gap-2">
              {['All', 'Electronics', 'Fashion', 'Home', 'Sports'].map((cat) => (
                <button
                  key={cat}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  {cat}
                </button>
              ))}
            </div>
            <select className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option>Sort by: Featured</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
              <option>Newest</option>
            </select>
          </div>

          {/* Products */}
          <ProductGrid />
        </div>
      </main>
      <Footer />
    </div>
  );
}
