'use client';

import Image from 'next/image';
import Link from 'next/link';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  category?: string;
  rating?: number;
}

export function ProductCard({ id, name, price, image, category, rating = 4.5 }: ProductCardProps) {
  return (
    <Link href={`/products/${id}`} className="group">
      <div className="bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all">
        {/* Image */}
        <div className="relative aspect-square bg-gradient-to-br from-slate-100 to-slate-50 overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center text-6xl">
            {image || '📦'}
          </div>
          {/* Quick Actions */}
          <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
            <button className="w-10 h-10 bg-white/80 backdrop-blur-xl rounded-full shadow-lg flex items-center justify-center hover:bg-indigo-500 hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </button>
          </div>
        </div>
        {/* Content */}
        <div className="p-4">
          {category && (
            <span className="text-xs font-medium text-indigo-600 uppercase tracking-wide">
              {category}
            </span>
          )}
          <h3 className="font-semibold text-slate-900 mt-1 group-hover:text-indigo-600 transition-colors">
            {name}
          </h3>
          <div className="flex items-center justify-between mt-2">
            <span className="text-lg font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              ${price.toFixed(2)}
            </span>
            {/* Rating */}
            <div className="flex items-center gap-1">
              <svg className="w-4 h-4 text-amber-400 fill-current" viewBox="0 0 20 20">
                <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
              </svg>
              <span className="text-sm text-slate-600">{rating}</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
