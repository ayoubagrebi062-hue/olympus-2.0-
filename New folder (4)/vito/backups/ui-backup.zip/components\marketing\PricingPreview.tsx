'use client';

import Link from 'next/link';

const plans = [
  {
    name: 'Free',
    price: '$0',
    desc: 'For trying out',
    features: ['5 projects', '1GB storage', 'Community support'],
    gradient: 'from-slate-500 to-slate-600',
  },
  {
    name: 'Pro',
    price: '$29',
    desc: 'For serious builders',
    features: ['Unlimited projects', '50GB storage', 'Priority support', 'Custom domains'],
    popular: true,
    gradient: 'from-indigo-500 to-purple-500',
  },
  {
    name: 'Team',
    price: '$99',
    desc: 'For teams',
    features: ['Everything in Pro', 'Team collaboration', 'SSO / SAML', 'Dedicated support'],
    gradient: 'from-purple-500 to-pink-500',
  },
];

export function PricingPreview() {
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-white via-indigo-50/30 to-white" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/80 backdrop-blur-xl border border-white/50 shadow-lg mb-6">
            <span className="text-sm font-semibold text-indigo-600">Pricing</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-6">
            Simple,{' '}
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent">
              transparent
            </span>{' '}
            pricing
          </h2>
          <p className="text-xl text-slate-600">
            Start free, upgrade when you are ready.
          </p>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`group relative p-8 rounded-2xl transition-all duration-500 ${
                plan.popular
                  ? 'bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white scale-105 shadow-[0_16px_48px_rgba(99,102,241,0.3)]'
                  : 'bg-white/80 backdrop-blur-2xl border border-white/50 shadow-[0_8px_32px_rgba(0,0,0,0.04)] hover:shadow-[0_16px_48px_rgba(99,102,241,0.12)] hover:-translate-y-1'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-white text-indigo-600 text-xs font-bold rounded-full shadow-lg">
                  MOST POPULAR
                </div>
              )}

              <h3 className={`text-xl font-bold mb-1 ${plan.popular ? 'text-white' : 'text-slate-900'}`}>
                {plan.name}
              </h3>
              <p className={`text-sm mb-6 ${plan.popular ? 'text-white/70' : 'text-slate-500'}`}>
                {plan.desc}
              </p>

              <div className="mb-8">
                <span className={`text-5xl font-black ${plan.popular ? 'text-white' : 'text-slate-900'}`}>
                  {plan.price}
                </span>
                <span className={plan.popular ? 'text-white/70' : 'text-slate-500'}>/mo</span>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className={`flex items-center gap-3 ${plan.popular ? 'text-white/90' : 'text-slate-600'}`}>
                    <svg className={`w-5 h-5 ${plan.popular ? 'text-white' : 'text-green-500'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>

              <Link
                href="/signup"
                className={`block w-full py-3 text-center font-semibold rounded-xl transition-all ${
                  plan.popular
                    ? 'bg-white text-indigo-600 hover:shadow-lg'
                    : 'bg-slate-100 text-slate-900 hover:bg-slate-200'
                }`}
              >
                Get Started
              </Link>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/pricing" className="inline-flex items-center gap-2 text-indigo-600 hover:text-indigo-700 font-semibold group">
            View full pricing details
            <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </section>
  );
}
