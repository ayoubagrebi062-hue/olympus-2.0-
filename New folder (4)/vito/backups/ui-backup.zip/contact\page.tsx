'use client';

import { Header, Footer } from '@/components/marketing';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          <section className="py-16 text-center">
            <h1 className="text-5xl font-bold text-slate-900 mb-6">
              Get in{' '}
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Touch
              </span>
            </h1>
            <p className="text-xl text-slate-600">
              Have questions? We would love to hear from you.
            </p>
          </section>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Form */}
            <div className="bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-lg">
              <form className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Name</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                  <input
                    type="email"
                    className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="you@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Message</label>
                  <textarea
                    rows={4}
                    className="w-full px-4 py-3 bg-white/50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="How can we help?"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                >
                  Send Message
                </button>
              </form>
            </div>

            {/* Info */}
            <div className="space-y-6">
              {[
                { icon: '📧', title: 'Email', value: 'hello@olympus.dev' },
                { icon: '💬', title: 'Discord', value: 'discord.gg/olympus' },
                { icon: '🐦', title: 'Twitter', value: '@olympusdev' },
              ].map((c) => (
                <div key={c.title} className="p-6 bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl shadow-lg flex items-center gap-4">
                  <div className="text-3xl">{c.icon}</div>
                  <div>
                    <div className="font-medium text-slate-900">{c.title}</div>
                    <div className="text-indigo-600">{c.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
