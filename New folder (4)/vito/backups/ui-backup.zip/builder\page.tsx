'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui';

interface FileNode {
  name: string;
  type: 'file' | 'folder';
  path: string;
  children?: FileNode[];
  content?: string;
}

interface BuildPlan {
  name: string;
  description: string;
  files: Array<{ path: string; type: string; description: string }>;
  components: string[];
  features: string[];
  stack: string[];
}

const defaultFiles: FileNode[] = [
  {
    name: 'src',
    type: 'folder',
    path: 'src',
    children: [
      {
        name: 'app',
        type: 'folder',
        path: 'src/app',
        children: [
          { name: 'page.tsx', type: 'file', path: 'src/app/page.tsx', content: '// Your app will appear here\n\nexport default function Home() {\n  return (\n    <div>\n      <h1>Hello World</h1>\n    </div>\n  );\n}' },
          { name: 'layout.tsx', type: 'file', path: 'src/app/layout.tsx', content: '// Root layout' },
        ],
      },
      {
        name: 'components',
        type: 'folder',
        path: 'src/components',
        children: [],
      },
    ],
  },
  { name: 'package.json', type: 'file', path: 'package.json', content: '{\n  "name": "my-app"\n}' },
];

export default function BuilderPage() {
  const [tokens, setTokens] = useState(5);
  const [prompt, setPrompt] = useState('');
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [projectName, setProjectName] = useState('my-project');
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState(0);
  const [buildStatus, setBuildStatus] = useState('');
  const [files, setFiles] = useState<FileNode[]>(defaultFiles);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [showSignupPrompt, setShowSignupPrompt] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([]);
  const [buildPlan, setBuildPlan] = useState<BuildPlan | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  // Convert build plan to file tree
  const planToFileTree = useCallback((plan: BuildPlan): FileNode[] => {
    const root: FileNode = {
      name: 'src',
      type: 'folder',
      path: 'src',
      children: [],
    };

    // Group files by directory
    const dirs = new Map<string, FileNode>();
    dirs.set('src', root);

    for (const file of plan.files) {
      const parts = file.path.split('/');
      let currentPath = '';

      for (let i = 0; i < parts.length - 1; i++) {
        const part = parts[i];
        const parentPath = currentPath;
        currentPath = currentPath ? `${currentPath}/${part}` : part;

        if (!dirs.has(currentPath)) {
          const folder: FileNode = {
            name: part,
            type: 'folder',
            path: currentPath,
            children: [],
          };
          dirs.set(currentPath, folder);

          // Add to parent
          const parent = dirs.get(parentPath);
          if (parent && parent.children) {
            parent.children.push(folder);
          }
        }
      }

      // Add file
      const fileName = parts[parts.length - 1];
      const parentPath = parts.slice(0, -1).join('/');
      const parent = dirs.get(parentPath);

      if (parent && parent.children) {
        parent.children.push({
          name: fileName,
          type: 'file',
          path: file.path,
          content: `// ${file.description}\n// TODO: Generate actual code`,
        });
      }
    }

    return [
      root,
      {
        name: 'package.json',
        type: 'file',
        path: 'package.json',
        content: JSON.stringify({
          name: plan.name,
          version: '0.1.0',
          dependencies: plan.stack.reduce((acc, tech) => {
            if (tech.toLowerCase().includes('react')) acc['react'] = '^18.2.0';
            if (tech.toLowerCase().includes('next')) acc['next'] = '^14.0.0';
            if (tech.toLowerCase().includes('tailwind')) acc['tailwindcss'] = '^3.3.0';
            return acc;
          }, {} as Record<string, string>),
        }, null, 2),
      },
    ];
  }, []);

  useEffect(() => {
    // Load from localStorage
    if (typeof window !== 'undefined') {
      const savedTokens = localStorage.getItem('olympus_tokens');
      const savedPrompt = localStorage.getItem('olympus_initial_prompt');
      const savedSession = localStorage.getItem('olympus_session_id');

      if (savedTokens) setTokens(parseInt(savedTokens));
      if (savedSession) setSessionId(savedSession);

      if (savedPrompt) {
        // Start building automatically
        startBuild(savedPrompt);
        localStorage.removeItem('olympus_initial_prompt');
      }
    }
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startBuild = async (buildPrompt: string) => {
    setIsBuilding(true);
    setBuildProgress(0);
    setMessages((prev) => [...prev, { role: 'user', content: buildPrompt }]);

    // Get or create session ID
    let currentSessionId = sessionId;
    if (!currentSessionId) {
      currentSessionId = crypto.randomUUID();
      setSessionId(currentSessionId);
      localStorage.setItem('olympus_session_id', currentSessionId);
    }

    // Show initial progress
    setBuildStatus('Connecting to 50X AI...');
    setBuildProgress(10);

    try {
      // Call the 50X guest API
      const response = await fetch('/api/guest/50x', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: buildPrompt,
          sessionId: currentSessionId,
          framework: 'react',
          targetScore: 80,
          maxIterations: 2,
          enableVision: false,
          enableRAG: true,
        }),
      });

      setBuildProgress(30);
      setBuildStatus('Running 50X pipeline...');

      const result = await response.json();

      if (!response.ok) {
        // Handle token exhaustion
        if (result.error?.code === 'TOKEN_001') {
          setTokens(0);
          localStorage.setItem('olympus_tokens', '0');
          setShowSignupPrompt(true);
        }
        throw new Error(result.error?.message || 'Build failed');
      }

      // Update tokens from session
      if (result.session) {
        setTokens(result.session.tokensRemaining);
        localStorage.setItem('olympus_tokens', result.session.tokensRemaining.toString());

        if (result.session.tokensRemaining === 0) {
          setShowSignupPrompt(true);
        }
      }

      setBuildProgress(60);
      setBuildStatus('Processing generated code...');

      // Process 50X result
      if (result.data) {
        const { code, filename, score, review, security, iterations } = result.data;

        // Create file structure from generated code
        const generatedFile: FileNode = {
          name: filename || 'Component.tsx',
          type: 'file',
          path: `src/components/${filename || 'Component.tsx'}`,
          content: code,
        };

        // Update file tree
        setFiles((prev) => {
          const newFiles = [...prev];
          const srcFolder = newFiles.find((f) => f.name === 'src');
          if (srcFolder?.children) {
            const componentsFolder = srcFolder.children.find((f) => f.name === 'components');
            if (componentsFolder?.children) {
              componentsFolder.children.push(generatedFile);
            }
          }
          return newFiles;
        });

        // Select the new file
        setSelectedFile(generatedFile);
        setProjectName(filename?.replace(/\.[^.]+$/, '') || 'my-component');

        setBuildProgress(90);
        setBuildStatus('Finalizing...');

        await new Promise((resolve) => setTimeout(resolve, 500));
        setBuildProgress(100);
        setBuildStatus('Build complete!');

        // Add AI response with generation details
        const resultSummary = `Generated your component using the **50X Pipeline**:

**File:** \`${filename || 'Component.tsx'}\`

**Quality Score:** ${score}/100 ${score >= 85 ? '(Excellent)' : score >= 70 ? '(Good)' : '(Needs improvement)'}

**Iterations:** ${iterations || 1} code refinement${(iterations || 1) > 1 ? 's' : ''}

**Security:** ${security?.passed ? 'Passed' : `${security?.issues || 0} issues found`}

**Review:** ${review?.summary || 'Component generated successfully'}

The code is ready in the editor. Ask me to make changes or refine it!`;

        setMessages((prev) => [...prev, { role: 'assistant', content: resultSummary }]);
      }

    } catch (error) {
      console.error('Build error:', error);
      setBuildStatus('Build failed');

      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: `Sorry, there was an error: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again.`,
        },
      ]);
    } finally {
      setIsBuilding(false);
    }
  };

  const handleSendMessage = async () => {
    if (!prompt.trim() || tokens === 0) return;

    const userMessage = prompt;
    setPrompt('');
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);

    // Get or create session ID
    let currentSessionId = sessionId;
    if (!currentSessionId) {
      currentSessionId = crypto.randomUUID();
      setSessionId(currentSessionId);
      localStorage.setItem('olympus_session_id', currentSessionId);
    }

    try {
      // Call 50X API for follow-up changes
      const response = await fetch('/api/guest/50x', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMessage,
          sessionId: currentSessionId,
          framework: 'react',
          targetScore: 80,
          maxIterations: 2,
          enableVision: false,
          enableRAG: true,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.error?.code === 'TOKEN_001') {
          setTokens(0);
          localStorage.setItem('olympus_tokens', '0');
          setShowSignupPrompt(true);
        }
        throw new Error(result.error?.message || 'Request failed');
      }

      // Update tokens from session
      if (result.session) {
        setTokens(result.session.tokensRemaining);
        localStorage.setItem('olympus_tokens', result.session.tokensRemaining.toString());

        if (result.session.tokensRemaining === 0) {
          setShowSignupPrompt(true);
        }
      }

      // Process 50X result
      if (result.data) {
        const { code, filename, score, review } = result.data;

        // Update file in tree
        const generatedFile: FileNode = {
          name: filename || 'Component.tsx',
          type: 'file',
          path: `src/components/${filename || 'Component.tsx'}`,
          content: code,
        };

        setFiles((prev) => {
          const newFiles = [...prev];
          const srcFolder = newFiles.find((f) => f.name === 'src');
          if (srcFolder?.children) {
            const componentsFolder = srcFolder.children.find((f) => f.name === 'components');
            if (componentsFolder?.children) {
              // Replace existing or add new
              const existingIndex = componentsFolder.children.findIndex((f) => f.name === generatedFile.name);
              if (existingIndex >= 0) {
                componentsFolder.children[existingIndex] = generatedFile;
              } else {
                componentsFolder.children.push(generatedFile);
              }
            }
          }
          return newFiles;
        });

        setSelectedFile(generatedFile);

        // Add AI response
        setMessages((prev) => [
          ...prev,
          {
            role: 'assistant',
            content: `Updated! Score: ${score}/100. ${review?.summary || 'Changes applied.'}`,
          },
        ]);
      }

    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: `Sorry, I couldn't process that: ${error instanceof Error ? error.message : 'Please try again.'}`,
        },
      ]);
    }
  };

  const renderFileTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map((node) => (
      <div key={node.path}>
        <button
          onClick={() => node.type === 'file' && setSelectedFile(node)}
          className={`w-full text-left px-2 py-1 text-sm rounded hover:bg-white/5 flex items-center gap-2 ${
            selectedFile?.path === node.path ? 'bg-white/10 text-white' : 'text-white/60'
          }`}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          {node.type === 'folder' ? (
            <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2 6a2 2 0 012-2h5l2 2h5a2 2 0 012 2v6a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" />
            </svg>
          ) : (
            <svg className="w-4 h-4 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          )}
          {node.name}
        </button>
        {node.children && renderFileTree(node.children, depth + 1)}
      </div>
    ));
  };

  return (
    <div className="h-screen flex flex-col bg-[#0a0a0a] text-white">
      {/* Header */}
      <header className="h-14 border-b border-white/10 flex items-center justify-between px-4 bg-[#0a0a0a]">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-gradient-to-br from-primary-500 to-primary-700 rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <span className="font-bold">OLYMPUS</span>
          </Link>
          <span className="text-white/40">|</span>
          <span className="text-sm text-white/60">{projectName}</span>
        </div>

        <div className="flex items-center gap-4">
          {/* Token counter */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full">
            <svg className="w-4 h-4 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.736 6.979C9.208 6.193 9.696 6 10 6c.304 0 .792.193 1.264.979a1 1 0 001.715-1.029C12.279 4.784 11.232 4 10 4s-2.279.784-2.979 1.95c-.285.475-.507 1-.67 1.55H6a1 1 0 000 2h.013a9.358 9.358 0 000 1H6a1 1 0 100 2h.351c.163.55.385 1.075.67 1.55C7.721 15.216 8.768 16 10 16s2.279-.784 2.979-1.95a1 1 0 10-1.715-1.029c-.472.786-.96.979-1.264.979-.304 0-.792-.193-1.264-.979a4.265 4.265 0 01-.264-.521H10a1 1 0 100-2H8.017a7.36 7.36 0 010-1H10a1 1 0 100-2H8.472c.08-.185.167-.36.264-.521z" />
            </svg>
            <span className="text-sm font-medium">{tokens}</span>
            <span className="text-xs text-white/40">tokens</span>
          </div>

          <Button variant="outline" size="sm">
            Share
          </Button>
          <Button size="sm">
            Deploy
          </Button>

          <div className="w-px h-6 bg-white/10" />

          <Button variant="ghost" size="sm" href="/login">
            Log in
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* File Explorer */}
        <aside className="w-64 border-r border-white/10 flex flex-col bg-[#0d0d0d]">
          <div className="p-3 border-b border-white/10">
            <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider">Files</h3>
          </div>
          <div className="flex-1 overflow-auto p-2">{renderFileTree(files)}</div>
        </aside>

        {/* Code Editor + Preview */}
        <main className="flex-1 flex flex-col">
          {/* Editor */}
          <div className="flex-1 flex">
            <div className="flex-1 border-r border-white/10 flex flex-col">
              <div className="h-10 border-b border-white/10 flex items-center px-4 bg-[#0d0d0d]">
                <span className="text-sm text-white/60">{selectedFile?.path || 'Select a file'}</span>
              </div>
              <div className="flex-1 overflow-auto p-4 font-mono text-sm">
                {isBuilding ? (
                  <div className="h-full flex flex-col items-center justify-center">
                    <div className="w-64 mb-4">
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-primary-500 to-violet-500 transition-all duration-500"
                          style={{ width: `${buildProgress}%` }}
                        />
                      </div>
                    </div>
                    <p className="text-white/60">{buildStatus}</p>
                  </div>
                ) : selectedFile?.content ? (
                  <pre className="text-white/80">{selectedFile.content}</pre>
                ) : (
                  <p className="text-white/40">Select a file to view its contents</p>
                )}
              </div>
            </div>

            {/* Preview */}
            <div className="w-1/2 flex flex-col">
              <div className="h-10 border-b border-white/10 flex items-center justify-between px-4 bg-[#0d0d0d]">
                <span className="text-sm text-white/60">Preview</span>
                <div className="flex items-center gap-2">
                  <button className="p-1 hover:bg-white/10 rounded">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  </button>
                </div>
              </div>
              <div className="flex-1 bg-white">
                <iframe
                  className="w-full h-full border-0"
                  srcDoc={`
                    <!DOCTYPE html>
                    <html>
                      <head>
                        <style>
                          body { font-family: system-ui, sans-serif; padding: 2rem; }
                          h1 { color: #333; }
                        </style>
                      </head>
                      <body>
                        <h1>Hello World</h1>
                        <p>Your app preview will appear here.</p>
                      </body>
                    </html>
                  `}
                />
              </div>
            </div>
          </div>
        </main>

        {/* AI Chat */}
        <aside className="w-80 border-l border-white/10 flex flex-col bg-[#0d0d0d]">
          <div className="p-3 border-b border-white/10">
            <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider">AI Assistant</h3>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-auto p-4 space-y-4">
            {messages.map((msg, i) => (
              <div key={i} className={`${msg.role === 'user' ? 'text-right' : ''}`}>
                <div
                  className={`inline-block max-w-[90%] p-3 rounded-xl text-sm ${
                    msg.role === 'user'
                      ? 'bg-primary-600 text-white'
                      : 'bg-white/5 text-white/80'
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-white/10">
            <div className="relative">
              <input
                type="text"
                placeholder={tokens > 0 ? 'Ask for changes...' : 'Sign up for more tokens'}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                disabled={tokens === 0}
                className="w-full px-4 py-3 pr-12 bg-white/5 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-primary-500/50 disabled:opacity-50"
              />
              <button
                onClick={handleSendMessage}
                disabled={!prompt.trim() || tokens === 0}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-white/60 hover:text-white disabled:opacity-50"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </div>
          </div>
        </aside>
      </div>

      {/* Signup Prompt */}
      {showSignupPrompt && (
        <div className="fixed bottom-4 right-4 max-w-sm bg-[#1a1a1a] border border-white/10 rounded-xl p-4 shadow-2xl">
          <h3 className="font-bold mb-2">Out of tokens!</h3>
          <p className="text-sm text-white/60 mb-4">
            Sign up to save your work and get 50 more tokens.
          </p>
          <div className="flex gap-2">
            <Button size="sm" href="/signup">
              Sign Up Free
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowSignupPrompt(false)}>
              Later
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
