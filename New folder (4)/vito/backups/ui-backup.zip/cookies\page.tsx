'use client';

import { Header, Footer } from '@/components/marketing';

export default function CookiePolicyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-slate-900 mb-8">Cookie Policy</h1>
          <div className="prose prose-lg prose-slate max-w-none bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-lg">
            <p className="text-slate-500 mb-8">Last updated: January 20, 2026</p>
            <h2>What Are Cookies</h2>
            <p>Cookies are small text files stored on your device when you visit websites.</p>

            <h2>How We Use Cookies</h2>
            <p><strong>Essential:</strong> Required for the platform to function (authentication, preferences).</p>
            <p><strong>Analytics:</strong> Help us understand how you use OLYMPUS to improve our service.</p>
            <p><strong>Marketing:</strong> Used to show relevant content and measure campaign effectiveness.</p>

            <h2>Managing Cookies</h2>
            <p>You can control cookies through your browser settings. Note that disabling essential cookies may affect functionality.</p>

            <h2>Third-Party Cookies</h2>
            <p>We use services like Google Analytics and Stripe that may set their own cookies.</p>

            <h2>Updates</h2>
            <p>We may update this policy. Check back periodically for changes.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
