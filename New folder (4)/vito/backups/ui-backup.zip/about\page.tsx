'use client';

import { Header, Footer } from '@/components/marketing';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          {/* Hero */}
          <section className="py-16 text-center">
            <h1 className="text-5xl font-bold text-slate-900 mb-6">
              About{' '}
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                OLYMPUS
              </span>
            </h1>
            <p className="text-xl text-slate-600">
              We are building the future of app development.
            </p>
          </section>

          {/* Mission */}
          <section className="py-12">
            <div className="bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-lg">
              <h2 className="text-2xl font-bold text-slate-900 mb-4">Our Mission</h2>
              <p className="text-slate-600 leading-relaxed">
                OLYMPUS was born from a simple idea: building software should not be this hard.
                We are combining the power of AI with intuitive design to create a platform where
                anyone can build production-ready apps, websites, and e-commerce stores in minutes,
                not months.
              </p>
            </div>
          </section>

          {/* Values */}
          <section className="py-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">Our Values</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { icon: '⚡', title: 'Speed', desc: '50X faster than traditional development.' },
                { icon: '🎯', title: 'Simplicity', desc: 'Powerful features, simple interface.' },
                { icon: '🔒', title: 'Security', desc: 'Enterprise-grade security by default.' },
              ].map((v) => (
                <div key={v.title} className="p-6 bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl text-center">
                  <div className="text-4xl mb-4">{v.icon}</div>
                  <h3 className="font-semibold text-slate-900 mb-2">{v.title}</h3>
                  <p className="text-slate-600 text-sm">{v.desc}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}
