'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { Header, Footer } from '@/components/marketing';

const posts: Record<string, { title: string; content: string; date: string; category: string; author: string }> = {
  '1': {
    title: 'Introducing OLYMPUS 2.0',
    content: `We are excited to announce OLYMPUS 2.0, the biggest update since we launched. This release brings AI-powered code generation to a whole new level.

## What is New

### AI Code Generation
Our new AI understands context better than ever. Describe what you want in plain English, and watch as production-ready code appears before your eyes.

### Visual Builder 2.0
The visual builder has been completely redesigned. Drag and drop components, see changes in real-time, and switch to code view whenever you need more control.

### One-Click Deploy
Deploy to production with a single click. We handle SSL, CDN, and scaling automatically.

## What is Next

We are just getting started. Stay tuned for more updates coming soon.`,
    date: 'Jan 20, 2026',
    category: 'Product',
    author: 'OLYMPUS Team',
  },
  '2': {
    title: 'How to Build an E-commerce Store in 10 Minutes',
    content: `Learn how to create a fully functional e-commerce store using OLYMPUS in just 10 minutes.

## Step 1: Create Your Project
Start by creating a new project in OLYMPUS. Select the E-commerce template to get started with pre-built components.

## Step 2: Customize Your Store
Use the visual builder to customize your store layout, colors, and branding. Add your products and configure payment settings.

## Step 3: Connect Payments
OLYMPUS integrates with Stripe out of the box. Connect your Stripe account and start accepting payments immediately.

## Step 4: Deploy
Click the deploy button and your store is live. Share the link with your customers and start selling.

That is it! You now have a fully functional e-commerce store.`,
    date: 'Jan 18, 2026',
    category: 'Tutorial',
    author: 'Sarah Chen',
  },
  '3': {
    title: 'The Future of No-Code Development',
    content: `AI is changing everything about how we build software. Here is what we see coming.

## The Current State

No-code tools have democratized software development. But they have limitations - complex logic, custom integrations, and scalability challenges.

## Enter AI

AI-powered development tools like OLYMPUS bridge the gap. You get the speed of no-code with the flexibility of traditional development.

## What is Next

We believe the future is hybrid - AI that understands your intent, generates code, but gives you full control when you need it.

The best developers will be those who can leverage AI effectively.`,
    date: 'Jan 15, 2026',
    category: 'Industry',
    author: 'Marcus Johnson',
  },
  '4': {
    title: 'Case Study: How Startup X Saved 6 Months',
    content: `Real results from a real startup using OLYMPUS to build their MVP.

## The Challenge

Startup X had a great idea but limited runway. They needed to launch fast to validate their concept before running out of money.

## The Solution

Using OLYMPUS, their small team built a complete SaaS platform in 3 weeks instead of the estimated 6 months.

## The Results

- 85% reduction in development time
- $150,000 saved in development costs
- Launched MVP 5 months ahead of schedule
- Successfully raised seed funding

## Key Takeaways

Speed matters in startups. Tools like OLYMPUS let you move fast without sacrificing quality.`,
    date: 'Jan 12, 2026',
    category: 'Case Study',
    author: 'Emily Rodriguez',
  },
};

export default function BlogPostPage() {
  const params = useParams();
  const slug = params?.slug as string;
  const post = posts[slug];

  if (!post) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
        <Header />
        <main className="pt-24 pb-16">
          <div className="max-w-4xl mx-auto px-4 text-center py-24">
            <h1 className="text-4xl font-bold text-slate-900 mb-4">Post Not Found</h1>
            <p className="text-slate-600 mb-8">The blog post you are looking for does not exist.</p>
            <Link href="/blog" className="text-indigo-600 hover:text-indigo-700 font-medium">
              Back to Blog
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <article className="max-w-4xl mx-auto px-4">
          {/* Back Link */}
          <Link href="/blog" className="inline-flex items-center gap-2 text-indigo-600 hover:text-indigo-700 mb-8">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back to Blog
          </Link>

          {/* Header */}
          <header className="mb-12">
            <div className="flex items-center gap-4 mb-4">
              <span className="px-3 py-1 bg-indigo-100 text-indigo-700 text-sm font-medium rounded-full">
                {post.category}
              </span>
              <span className="text-slate-500">{post.date}</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">{post.title}</h1>
            <p className="text-slate-600">By {post.author}</p>
          </header>

          {/* Content */}
          <div className="prose prose-lg prose-slate max-w-none">
            {post.content.split('\n\n').map((paragraph, i) => {
              if (paragraph.startsWith('## ')) {
                return <h2 key={i} className="text-2xl font-bold text-slate-900 mt-8 mb-4">{paragraph.replace('## ', '')}</h2>;
              }
              if (paragraph.startsWith('### ')) {
                return <h3 key={i} className="text-xl font-semibold text-slate-900 mt-6 mb-3">{paragraph.replace('### ', '')}</h3>;
              }
              if (paragraph.startsWith('- ')) {
                return (
                  <ul key={i} className="list-disc list-inside space-y-2 my-4">
                    {paragraph.split('\n').map((item, j) => (
                      <li key={j} className="text-slate-600">{item.replace('- ', '')}</li>
                    ))}
                  </ul>
                );
              }
              return <p key={i} className="text-slate-600 mb-4">{paragraph}</p>;
            })}
          </div>
        </article>
      </main>
      <Footer />
    </div>
  );
}
