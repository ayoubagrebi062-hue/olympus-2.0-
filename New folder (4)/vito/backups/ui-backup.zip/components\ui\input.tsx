'use client';

import { forwardRef, InputHTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Input Component
 *
 * Variants: default, ghost, filled
 * States: error, disabled
 */

const inputVariants = cva(
  // Base styles
  'w-full rounded-lg text-white transition-all duration-200 focus:outline-none placeholder:text-zinc-500 disabled:opacity-50 disabled:cursor-not-allowed',
  {
    variants: {
      variant: {
        // Default - Standard input
        default:
          'bg-zinc-900 border border-zinc-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent',

        // Ghost - Minimal border
        ghost:
          'bg-transparent border border-zinc-800 focus:border-zinc-600 focus:ring-1 focus:ring-zinc-600',

        // Filled - Solid background
        filled:
          'bg-zinc-800 border border-transparent focus:ring-2 focus:ring-blue-500',
      },
      inputSize: {
        sm: 'h-9 px-3 text-sm',
        md: 'h-11 px-4 text-base',
        lg: 'h-13 px-5 text-lg',
      },
      error: {
        true: 'border-red-500 focus:ring-red-500 focus:border-red-500',
        false: '',
      },
    },
    defaultVariants: {
      variant: 'default',
      inputSize: 'md',
      error: false,
    },
  }
);

export interface InputProps
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof inputVariants> {
  label?: string;
  helperText?: string;
  errorMessage?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      variant,
      inputSize,
      error,
      label,
      helperText,
      errorMessage,
      leftIcon,
      rightIcon,
      className,
      id,
      ...props
    },
    ref
  ) => {
    const inputId = id || `input-${Math.random().toString(36).slice(2, 9)}`;
    const hasError = error || !!errorMessage;

    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={inputId}
            className="block text-sm font-medium text-zinc-300 mb-2"
          >
            {label}
          </label>
        )}

        <div className="relative">
          {leftIcon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500">
              {leftIcon}
            </div>
          )}

          <input
            ref={ref}
            id={inputId}
            className={cn(
              inputVariants({ variant, inputSize, error: hasError }),
              leftIcon && 'pl-10',
              rightIcon && 'pr-10',
              className
            )}
            {...props}
          />

          {rightIcon && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500">
              {rightIcon}
            </div>
          )}
        </div>

        {(helperText || errorMessage) && (
          <p
            className={cn(
              'mt-2 text-sm',
              hasError ? 'text-red-400' : 'text-zinc-500'
            )}
          >
            {errorMessage || helperText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

export { inputVariants };
