'use client';

import { forwardRef, HTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Box Primitive
 *
 * The foundational layout primitive for all OLYMPUS components.
 * Based on Section 10 UI Component System.
 */

const boxVariants = cva('', {
  variants: {
    // Display
    display: {
      block: 'block',
      flex: 'flex',
      'inline-flex': 'inline-flex',
      grid: 'grid',
      'inline-block': 'inline-block',
      inline: 'inline',
      hidden: 'hidden',
    },
    // Position
    position: {
      relative: 'relative',
      absolute: 'absolute',
      fixed: 'fixed',
      sticky: 'sticky',
      static: 'static',
    },
    // Padding
    p: {
      0: 'p-0',
      1: 'p-1',
      2: 'p-2',
      3: 'p-3',
      4: 'p-4',
      5: 'p-5',
      6: 'p-6',
      8: 'p-8',
      10: 'p-10',
      12: 'p-12',
    },
    px: {
      0: 'px-0',
      1: 'px-1',
      2: 'px-2',
      3: 'px-3',
      4: 'px-4',
      5: 'px-5',
      6: 'px-6',
      8: 'px-8',
    },
    py: {
      0: 'py-0',
      1: 'py-1',
      2: 'py-2',
      3: 'py-3',
      4: 'py-4',
      5: 'py-5',
      6: 'py-6',
      8: 'py-8',
    },
    // Margin
    m: {
      0: 'm-0',
      1: 'm-1',
      2: 'm-2',
      3: 'm-3',
      4: 'm-4',
      auto: 'm-auto',
    },
    // Border Radius
    rounded: {
      none: 'rounded-none',
      sm: 'rounded-sm',
      md: 'rounded-md',
      lg: 'rounded-lg',
      xl: 'rounded-xl',
      '2xl': 'rounded-2xl',
      '3xl': 'rounded-3xl',
      full: 'rounded-full',
    },
    // Width
    w: {
      full: 'w-full',
      auto: 'w-auto',
      screen: 'w-screen',
      fit: 'w-fit',
    },
    // Height
    h: {
      full: 'h-full',
      auto: 'h-auto',
      screen: 'h-screen',
      fit: 'h-fit',
    },
  },
  defaultVariants: {},
});

export interface BoxProps
  extends HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof boxVariants> {
  as?: 'div' | 'section' | 'article' | 'aside' | 'header' | 'footer' | 'main' | 'nav' | 'span';
}

const Box = forwardRef<HTMLDivElement, BoxProps>(
  ({ as: Component = 'div', display, position, p, px, py, m, rounded, w, h, className, ...props }, ref) => {
    return (
      <Component
        ref={ref as any}
        className={cn(boxVariants({ display, position, p, px, py, m, rounded, w, h }), className)}
        {...props}
      />
    );
  }
);

Box.displayName = 'Box';

export { Box, boxVariants };
