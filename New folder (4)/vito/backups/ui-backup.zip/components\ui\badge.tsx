'use client';

import { forwardRef, HTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Badge Component
 *
 * Variants: default, primary, success, warning, error, outline
 * Sizes: sm, md, lg
 */

const badgeVariants = cva(
  // Base styles
  'inline-flex items-center justify-center font-medium rounded-full transition-colors',
  {
    variants: {
      variant: {
        // Default - Subtle background
        default: 'bg-zinc-800 text-zinc-300',

        // Primary - Brand color
        primary: 'bg-blue-500/20 text-blue-400',

        // Success - Green
        success: 'bg-green-500/20 text-green-400',

        // Warning - Amber
        warning: 'bg-amber-500/20 text-amber-400',

        // Error - Red
        error: 'bg-red-500/20 text-red-400',

        // Outline - Border only
        outline: 'border border-zinc-600 text-zinc-400',

        // Premium - Gradient
        premium: 'bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-400',
      },
      size: {
        sm: 'px-2 py-0.5 text-xs',
        md: 'px-2.5 py-1 text-sm',
        lg: 'px-3 py-1.5 text-base',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
);

export interface BadgeProps
  extends HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  dot?: boolean;
}

export const Badge = forwardRef<HTMLSpanElement, BadgeProps>(
  ({ variant, size, dot, className, children, ...props }, ref) => {
    return (
      <span
        ref={ref}
        className={cn(badgeVariants({ variant, size }), className)}
        {...props}
      >
        {dot && (
          <span
            className={cn(
              'w-1.5 h-1.5 rounded-full mr-1.5',
              variant === 'success' && 'bg-green-400',
              variant === 'warning' && 'bg-amber-400',
              variant === 'error' && 'bg-red-400',
              variant === 'primary' && 'bg-blue-400',
              (!variant || variant === 'default' || variant === 'outline') &&
                'bg-zinc-400'
            )}
          />
        )}
        {children}
      </span>
    );
  }
);

Badge.displayName = 'Badge';

export { badgeVariants };
