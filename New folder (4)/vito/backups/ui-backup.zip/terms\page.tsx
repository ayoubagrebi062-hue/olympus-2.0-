'use client';

import { Header, Footer } from '@/components/marketing';

export default function TermsofServicePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <Header />
      <main className="pt-24 pb-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-slate-900 mb-8">Terms of Service</h1>
          <div className="prose prose-lg prose-slate max-w-none bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-lg">
            <p className="text-slate-500 mb-8">Last updated: January 20, 2026</p>
            <h2>1. Acceptance of Terms</h2>
            <p>By using OLYMPUS, you agree to these Terms of Service and our Privacy Policy.</p>

            <h2>2. Use of Service</h2>
            <p>You may use OLYMPUS for lawful purposes only. You are responsible for all activity under your account.</p>

            <h2>3. Intellectual Property</h2>
            <p>You retain ownership of content you create. We retain ownership of the OLYMPUS platform and technology.</p>

            <h2>4. Payment Terms</h2>
            <p>Paid plans are billed monthly or annually. Refunds are available within 14 days of purchase.</p>

            <h2>5. Limitation of Liability</h2>
            <p>OLYMPUS is provided "as is" without warranties. Our liability is limited to the amount you paid us.</p>

            <h2>6. Changes to Terms</h2>
            <p>We may update these terms. Continued use after changes constitutes acceptance.</p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
