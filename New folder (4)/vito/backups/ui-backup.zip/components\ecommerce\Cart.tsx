'use client';

import { useState } from 'react';
import Link from 'next/link';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

const SAMPLE_CART: CartItem[] = [
  { id: '1', name: 'Premium Headphones', price: 299.99, quantity: 1, image: '🎧' },
  { id: '2', name: 'Smart Watch Pro', price: 449.99, quantity: 2, image: '⌚' },
];

export function Cart() {
  const [items, setItems] = useState<CartItem[]>(SAMPLE_CART);

  const updateQuantity = (id: string, delta: number) => {
    setItems(items.map(item =>
      item.id === id
        ? { ...item, quantity: Math.max(0, item.quantity + delta) }
        : item
    ).filter(item => item.quantity > 0));
  };

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 100 ? 0 : 9.99;
  const total = subtotal + shipping;

  return (
    <div className="bg-white/60 backdrop-blur-xl border border-white/20 rounded-2xl shadow-xl overflow-hidden">
      <div className="p-6 border-b border-slate-200">
        <h2 className="text-xl font-bold text-slate-900">Shopping Cart</h2>
        <p className="text-slate-500 text-sm">{items.length} items</p>
      </div>

      {/* Items */}
      <div className="divide-y divide-slate-100">
        {items.map((item) => (
          <div key={item.id} className="p-6 flex items-center gap-4">
            <div className="w-16 h-16 bg-slate-100 rounded-xl flex items-center justify-center text-3xl">
              {item.image}
            </div>
            <div className="flex-1">
              <h3 className="font-medium text-slate-900">{item.name}</h3>
              <p className="text-indigo-600 font-semibold">${item.price.toFixed(2)}</p>
            </div>
            {/* Quantity */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateQuantity(item.id, -1)}
                className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors"
              >
                -
              </button>
              <span className="w-8 text-center font-medium">{item.quantity}</span>
              <button
                onClick={() => updateQuantity(item.id, 1)}
                className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 flex items-center justify-center transition-colors"
              >
                +
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="p-6 bg-slate-50/50 space-y-3">
        <div className="flex justify-between text-slate-600">
          <span>Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-slate-600">
          <span>Shipping</span>
          <span>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
        </div>
        <div className="flex justify-between text-lg font-bold text-slate-900 pt-3 border-t border-slate-200">
          <span>Total</span>
          <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            ${total.toFixed(2)}
          </span>
        </div>
        <Link
          href="/checkout"
          className="block w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold text-center rounded-xl shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:-translate-y-0.5 transition-all mt-4"
        >
          Proceed to Checkout
        </Link>
      </div>
    </div>
  );
}
