'use client';

import { DashboardLayout, StatCard, ChartCard, RecentOrders } from '@/components/dashboard';

export default function DashboardPage() {
  const stats = [
    { title: 'Total Revenue', value: '$45,231', change: '+20.1% from last month', changeType: 'positive' as const, icon: '💰' },
    { title: 'Orders', value: '2,345', change: '+12.5% from last month', changeType: 'positive' as const, icon: '📦' },
    { title: 'Customers', value: '1,234', change: '+8.2% from last month', changeType: 'positive' as const, icon: '👥' },
    { title: 'Conversion', value: '3.2%', change: '-0.4% from last month', changeType: 'negative' as const, icon: '📈' },
  ];

  return (
    <DashboardLayout>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-1">Welcome back! Here is your store overview.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <StatCard key={stat.title} {...stat} />
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <ChartCard title="Revenue Overview" subtitle="Weekly revenue performance" />
        <ChartCard title="Orders" subtitle="Weekly order count" />
      </div>

      {/* Recent Orders */}
      <RecentOrders />
    </DashboardLayout>
  );
}
