'use client';

import { forwardRef, HTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

/**
 * OLYMPUS Text Primitive
 *
 * Typography primitive with LIGHT THEME colors.
 * Based on Section 10 UI Component System.
 */

const textVariants = cva('', {
  variants: {
    // Text Styles (Pre-composed)
    variant: {
      h1: 'text-5xl font-bold leading-tight tracking-tight text-slate-900',
      h2: 'text-4xl font-semibold leading-tight tracking-tight text-slate-900',
      h3: 'text-3xl font-semibold leading-snug text-slate-900',
      h4: 'text-2xl font-semibold leading-snug text-slate-900',
      h5: 'text-xl font-semibold leading-normal text-slate-900',
      h6: 'text-lg font-semibold leading-normal text-slate-900',
      body: 'text-base font-normal leading-relaxed text-slate-700',
      'body-sm': 'text-sm font-normal leading-relaxed text-slate-600',
      caption: 'text-xs font-normal leading-normal text-slate-500',
      label: 'text-sm font-medium leading-normal text-slate-700',
      code: 'font-mono text-sm leading-relaxed',
    },
    // Font Size
    size: {
      xs: 'text-xs',
      sm: 'text-sm',
      base: 'text-base',
      lg: 'text-lg',
      xl: 'text-xl',
      '2xl': 'text-2xl',
      '3xl': 'text-3xl',
      '4xl': 'text-4xl',
      '5xl': 'text-5xl',
      '6xl': 'text-6xl',
      '7xl': 'text-7xl',
    },
    // Font Weight
    weight: {
      light: 'font-light',
      normal: 'font-normal',
      medium: 'font-medium',
      semibold: 'font-semibold',
      bold: 'font-bold',
      extrabold: 'font-extrabold',
    },
    // Text Color (LIGHT THEME)
    color: {
      primary: 'text-slate-900',
      secondary: 'text-slate-700',
      tertiary: 'text-slate-500',
      muted: 'text-slate-400',
      brand: 'text-blue-600',
      success: 'text-green-600',
      warning: 'text-amber-600',
      error: 'text-red-600',
      white: 'text-white',
    },
    // Text Align
    align: {
      left: 'text-left',
      center: 'text-center',
      right: 'text-right',
    },
    // Gradient Text
    gradient: {
      brand: 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent',
      premium: 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 bg-clip-text text-transparent',
      none: '',
    },
  },
  defaultVariants: {
    variant: 'body',
    gradient: 'none',
  },
});

export interface TextProps
  extends HTMLAttributes<HTMLElement>,
    VariantProps<typeof textVariants> {
  as?: 'p' | 'span' | 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'label' | 'div';
}

const Text = forwardRef<HTMLElement, TextProps>(
  ({ as, variant, size, weight, color, align, gradient, className, ...props }, ref) => {
    // Auto-select element based on variant
    const Component = as || (variant?.startsWith('h') ? variant : 'p') as any;

    return (
      <Component
        ref={ref}
        className={cn(textVariants({ variant, size, weight, color, align, gradient }), className)}
        {...props}
      />
    );
  }
);

Text.displayName = 'Text';

export { Text, textVariants };
